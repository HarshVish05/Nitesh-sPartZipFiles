package com.nkdebug.securitysample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuritySampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
